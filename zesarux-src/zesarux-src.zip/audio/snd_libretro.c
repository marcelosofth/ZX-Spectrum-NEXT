/*
 * snd_libretro.c - driver de audio do core libretro do ZEsarUX
 *
 * Derivado de audio/audionull.c. A interface e a mesma de qualquer driver de
 * som: o emulador preenche um buffer de samples e chama audio_send_frame().
 * Nosotros guardamos esse buffer para o core entregar ao RetroArch.
 *
 * -----------------------------------------------------------------------
 * A TAXA DE SAIDA E UMA VARIAVEL, E ISTO E IMPORTANTE
 * -----------------------------------------------------------------------
 *
 * audio.h:52   #define FRECUENCIA_SONIDO frecuencia_sonido_variable
 * audio.c:702  int frecuencia_sonido_variable = FRECUENCIA_CONSTANTE_NORMAL_SONIDO;
 * audio.h:47   #define FRECUENCIA_CONSTANTE_NORMAL_SONIDO (312*50)   // = 15600
 *
 * Ou seja: 15600 Hz e a frequencia base do AY (312 ciclos por linha de
 * varredura, 50 Hz de video). NAO e a taxa de saida de audio. A taxa real de
 * playback e frecuencia_sonido_variable, e ela muda conforme a velocidade da
 * emulacao:
 *
 * cpu.c:1379   frecuencia_sonido_variable = FRECUENCIA_CONSTANTE_NORMAL_SONIDO
 *                                              * porcentaje_velocidad_emulador / 100;
 *
 * Repare que a conta esta em cpu.c, e nao em audio.c. Quando a velocidade
 * muda, o proprio emulador fecha o driver de audio (audio_end), ajusta a
 * frequencia e so entao reabre (audio_init). Nos fazemos o mesmo: nosso
 * audio_libretro_init le a variavel e recalcula o tamanho em samples.
 *
 * Se announce no av_info um sample_rate fixo e a maquina rodar a outra
 * velocidade, o audio sai com o pitch errado -- e isso so aparece como chiado
 * ou afinado, nunca como erro.
 *
 * -----------------------------------------------------------------------
 * O FORMATO DO BUFFER
 * -----------------------------------------------------------------------
 *
 * audio.h:37   #define FRAMES_VECES_BUFFER_AUDIO 5
 * audio.h:40   #define AUDIO_BUFFER_SIZE (312*FRAMES_VECES_BUFFER_AUDIO)  // = 1560
 * audio.c:85   char audio_buffer_one_assigned[AUDIO_BUFFER_SIZE*2];  //Doble porque es estereo
 * audio.c:1425 audio_send_frame(audio_buffer_playback);
 *
 * O buffer chega como char*, com AUDIO_BUFFER_SIZE amostras, em pares
 * esquerda/direita. E o mesmo formato que o audionull receberia e que o
 * audiodsp consome. Nao ha conversao a fazer alem de copiar.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "compileoptions.h"
#include "cpu.h"
#include "audio.h"
#include "debug.h"
#include "settings.h"

#include "snd_libretro.h"

/* Capacidade do buffer circular. O ZEsarUX entrega AUDIO_BUFFER_SIZE amostras
 * de 5 em 5 quadros. Com folga para o caso de o core atrasar, o que acontece
 * se o frontend ficar lento. */
#define SND_RING_FRAMES 8192

static int16_t  *snd_ring;          /* amostras entrelacadas: E,D,E,D,... */
static int       snd_ring_frames;  /* capacidade em pares E/D */
static int       snd_ring_read;    /* onde o emulador escreve */
static int       snd_ring_write;   /* onde o core le            */

static int       snd_out_rate;     /* taxa que fluira para o av_info */

/* ------------------------------------------------------------ diagnostico --
 *
 * Tres perguntas, uma medida cada:
 *   1. envio_audio() e' chamado uma vez por QUADRO DE VIDEO ou uma vez a
 *      cada 5? O buffer tem AUDIO_BUFFER_SIZE = 312*5 = 1560 amostras, e o
 *      audio de um quadro de video a 50 Hz sao 312. Se envio_audio() rodar a
 *      cada quadro, o emulador esta entregando 5x audio demais.
 *   2. O ring enche? Se enche, e' porque chega mais do que sai.
 *   3. E o oposto -- quando le 2048 por quadro, quantas tem som?
 */
#ifdef ZX_TRACE_AUDIO
#include <stdint.h>
static unsigned long long snd_chamadas = 0;
static unsigned long long snd_amostras_entregues = 0;
static unsigned long long snd_quadros = 0;
static int snd_ring_cheio = 0;
#endif

int snd_libretro_init(void)
{
    debug_printf(VERBOSE_INFO, "Init libretro Audio Driver");

    if (!snd_ring)
    {
        snd_ring_frames = SND_RING_FRAMES;
        snd_ring = (int16_t *)malloc((size_t)snd_ring_frames * 2 * sizeof(int16_t));
        if (!snd_ring)
            return 1;
    }

    snd_ring_read  = 0;
    snd_ring_write = 0;

    /* Le a frequencia que o emulador realmente esta usando. Ver o cabecalho
     * deste arquivo: 15600 e o AY, nao a saida. */
    snd_out_rate = frecuencia_sonido_variable;

    audio_set_driver_name("libretro");

    return 0;
}

void snd_libretro_end(void)
{
    debug_printf(VERBOSE_INFO, "Ending libretro audio driver");
    audio_playing.v = 0;
#ifdef ZX_TRACE_AUDIO
    fprintf(stderr, "[snd] envio_audio chamado %llu vezes, empurrou %llu amostras"
                    "   em %llu quadros de video\n",
            snd_chamadas, snd_amostras_entregues, snd_quadros);
    fprintf(stderr, "[snd]   = %.1f amostras por quadro de video (o correto e' 312)\n",
            snd_quadros ? (double)snd_amostras_entregues / (double)snd_quadros : 0.0);
    fprintf(stderr, "[snd]   o ring tem %d posicoes;Buffer cheio? %s\n",
            snd_ring_frames, snd_ring_cheio ? "SIM" : "nao");
#endif
}

/* Chamado pelo ZEsarUX a cada 5 quadros, com o buffer stereo pronto. */
void snd_libretro_send_frame(char *buffer)
{
    int amostras;

    if (!snd_ring || !buffer)
        return;

#ifdef ZX_TRACE_AUDIO
    snd_chamadas++;
    snd_amostras_entregues += (unsigned long long)AUDIO_BUFFER_SIZE;
#endif

    /* O tamanho do buffer vem do proprio emulador: o codigo do audio.c
     * escreve AUDIO_BUFFER_SIZE amostras no buffer estereo que nos passa. */
    amostras = AUDIO_BUFFER_SIZE;

    {
        int i;
        for (i = 0; i < amostras; i++)
        {
            int proximo = snd_ring_write + 1;
            if (proximo >= snd_ring_frames)
                proximo = 0;

            /* Cheio: descartamos o mais antigo em vez de sobrescrever o que
             * o core ainda nao leu. Perder som e melhor que corromper a
             * memoria do frontend. */
            if (proximo == snd_ring_read)
            {
#ifdef ZX_TRACE_AUDIO
                snd_ring_cheio = 1;   /* chegou mais audio do que o core leu */
#endif
                break;
            }

            /* audio_buffer e char[AUDIO_BUFFER_SIZE*2]: 1 byte COM SINAL por
             * canal. Ler como int16_t juntava 2 amostras em uma e passava do
             * fim do buffer. Aqui: 8 bits -> 16 bits. */
            snd_ring[(size_t)snd_ring_write * 2]     = (int16_t)(((signed char *)buffer)[i * 2]     * 256);
            snd_ring[(size_t)snd_ring_write * 2 + 1] = (int16_t)(((signed char *)buffer)[i * 2 + 1] * 256);
            snd_ring_write = proximo;
        }
    }
}

int snd_libretro_thread_finish(void)
{
    return 0;
}

int snd_libretro_can_record_input(void)
{
    return 0;
}

void snd_libretro_get_buffer_info(int *buffer_size, int *current_buffer_position)
{
    if (buffer_size)
        *buffer_size = snd_ring_frames;
    if (current_buffer_position)
        *current_buffer_position = snd_ring_read;
}

/* ------------------------------------------------- leitura pelo core --- */

/* Tira ate max_frames pares E/D do buffer circular. Devolve quantos escreveu.
 * Se nao houver audio pronto, escreve silencio -- o frontend precisa de uma
 * taxa constante, e um retorno vazio faz o RetroArch repetir o ultimo bloco. */
size_t snd_libretro_read(int16_t *out, size_t max_frames)
{
    int    disponivel;
    int    cota;
    size_t i;

#ifdef ZX_TRACE_AUDIO
    snd_quadros++;
#endif

    if (!snd_ring || !out || !max_frames)
        return 0;

    /* A conta do disponivel precisa ser em int (ou com o ajuste manual do
     * wrap). Em size_t ela quebra: quando write < read, a subracao em int da
     * um numero NEGATIVO, que convertido para size_t vira um valor enorme --
     * e o "if (disponivel < 0)" nunca e' verdadeiro, porque size_t nao tem
     * sinal. Resultado: apos o primeiro wrap o ring e' lido do avesso, e o
     * que sai e' dado velho em vez do audio que acabou de chegar. */
    disponivel = snd_ring_write - snd_ring_read;
    if (disponivel < 0)
        disponivel += snd_ring_frames;

    /* Latencia: se acumulou mais de 2 blocos, descarta o excesso antigo. */
    if (disponivel > 2 * AUDIO_BUFFER_SIZE)
    {
        snd_ring_read = (snd_ring_read + disponivel - 2 * AUDIO_BUFFER_SIZE)
                        % snd_ring_frames;
        disponivel = 2 * AUDIO_BUFFER_SIZE;
    }

    /* O emulador entrega 5 quadros de audio de uma vez (1560 amostras), mas
     * cada retro_run so deve consumir 1 quadro (312). Pedir 2048 e esvaziar
     * o ring de uma vez = 1 quadro com som e 4 em silencio = 10 estalos/s. */
    cota = AUDIO_BUFFER_SIZE / FRAMES_VECES_BUFFER_AUDIO;
    if (disponivel > cota)
        disponivel = cota;

    if (disponivel > (int)max_frames)
        disponivel = (int)max_frames;

    for (i = 0; i < disponivel; i++)
    {
        out[i * 2]     = snd_ring[(size_t)snd_ring_read * 2];
        out[i * 2 + 1] = snd_ring[(size_t)snd_ring_read * 2 + 1];
        snd_ring_read++;
        if (snd_ring_read >= snd_ring_frames)
            snd_ring_read = 0;
    }

    /* Devolve so os pares realmente lidos. O glue deve chamar
     * audio_batch_cb(out, retorno), e nao max_frames. */
    return i;
}

/* Taxa de saida efetiva. O core anuncia isto no av_info. */
int snd_libretro_sample_rate(void)
{
    return snd_out_rate;
}