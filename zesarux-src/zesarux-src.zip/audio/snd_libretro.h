/*
 * snd_libretro.h - interface do driver de audio do core libretro.
 */
#ifndef SND_LIBRETRO_H
#define SND_LIBRETRO_H

#include <stdint.h>
#include <stddef.h>

/* Instala os ponteiros de driver do ZEsarUX (audio_send_frame e companhia).
 * Retorna 0 em caso de sucesso, diferente de zero se faltou memoria. */
int snd_libretro_init(void);

void snd_libretro_end(void);
void snd_libretro_send_frame(char *buffer);
int  snd_libretro_thread_finish(void);
int  snd_libretro_can_record_input(void);
void snd_libretro_get_buffer_info(int *buffer_size, int *current_buffer_position);

/* Tira ate max_frames pares esquerda/direita do buffer circular, completando
 * com silencio se faltar. Devolve sempre max_frames enquanto o driver existir. */
size_t snd_libretro_read(int16_t *out, size_t max_frames);

/* Taxa de saida em Hz, lida de frecuencia_sonido_variable no init. */
int snd_libretro_sample_rate(void);

#endif