#ifndef OPTIONS_H
#define OPTIONS_H

/*Configuracao minima para o core libretro.
 *
 * Este arquivo e o painel de chaves do ZEsarUX. O 'configure' reescreve ele a
 * cada build conforme as opcoes passadas. O arquivo que vinha no tarball era
 * residuo de uma build em Debian de outra pessoa, com SDL, X11, alsa, pulse,
 * ncurses, ssl, sndfile e joystick Linux todos ligados.
 *
 * Aqui NAO habilitamos nenhum driver de video ou audio: o core libretro
 * entra com os seus (scr_libretro.c, snd_libretro.c). Isso e o que permite
 * compilar sem SDL, sem X11, sem ncurses e sem nenhuma biblioteca externa.
 *
 * O que fica ligado e so a emulacao.
 */

/* --- emulacao: mantem --- */
#define EMULATE_MEMPTR
#define EMULATE_VISUALMEM
#define EMULATE_CPU_STATS
#define EMULATE_CONTEND
#define PUTPIXELCACHE

/* --- drivers de video: todos desligados --- */
/* #define COMPILE_STDOUT     nao: e o driver de saida padrao */
/* #define COMPILE_SIMPLETEXT nao */
/* #define COMPILE_CURSES     nao: exigiria ncurses */
/* #define COMPILE_XWINDOWS   nao: exigiria X11 */
/* #define COMPILE_SDL        nao: exigiria libSDL 1.2 */
/* #define COMPILE_FBDEV      nao: exigiria linux/fb.h */

/* --- drivers de audio: todos desligados --- */
/* #define COMPILE_DSP nao */
/* #define COMPILE_ONEBITSPEAKER nao */
/* #define COMPILE_ALSA nao */
/* #define COMPILE_PULSE nao */
/* #define USE_SNDFILE nao: exigiria sndfile.h */

/* --- recursos do sistema --- */
/* #define USE_XEXT nao */
/* #define COMPILE_SSL nao */
/* #define USE_LINUXREALJOYSTICK nao: o joypad vem do RetroArch */

/* Sem pthreads. O configure faz a MESMA coisa (linha 2509-2517): ao nao ligar
   USE_PTHREADS ele zera OPTIONNETWORKING e OPTIONLINUXREALJOYSTICK. */

/* NETWORKING_DISABLED e obrigatorio junto com USE_PTHREADS desligado.
   Sem esta define, stats.c, zxvision.c e menu_items.c chamam pthread_create
   sem guarda e o build falha. O proprio codigo ja espera por ela -- em
   stats.c: "#ifndef NETWORKING_DISABLED" envolve toda a criacao da thread.
   Sem rede, o core ganha mais uma coisa: nenhuma thread no RetroArch. */
#define NETWORKING_DISABLED

/* --- drivers que o core vai trazer --- */
/* O scr_libretro.c implementa a interface de video (scr_putpixel e
   scr_refresca_pantalla). O snd_libretro.c implementa a de audio
   (audio_send_frame). Nenhum dos dois precisa de uma define aqui. */

#define COMPILATION_DATE "Thu Oct  1 08:00:00 BRT 2026"
#define COMPILATION_SYSTEM "MinGW-w64 (Windows x86_64)"
#define COMPILATION_SYSTEM_RELEASE "core libretro"
#define COMPILATION_MACHINE_HARDWARE_NAME "x86_64"
#define CONFIGURE_OPTIONS "make -f Makefile.win (core libretro, sem drivers externos)"
#define COMPILE_VARIABLES " EMULATE_MEMPTR EMULATE_VISUALMEM EMULATE_CPU_STATS EMULATE_CONTEND PUTPIXELCACHE"
#define COMPILE_INITIALCFLAGS "-O2"
#define COMPILE_INITIALLDFLAGS ""
#define COMPILE_INITIALLIBS ""
#define COMPILE_FINALCFLAGS "-O2 -fsigned-char -DMINGW -I. -Iaudio -Icopy_interfaces -Icores -Icpus -Imachines -Imenu -Isnap -Istorage -Isoundchips -Ithird_party -Ivideo -Ivideo_chips -Izrcp -Izxvision"
#define COMPILE_FINALLDFLAGS ""
#define COMPILE_FINALLIBS ""
#define INSTALL_PREFIX ""

#define LINES_SOURCE 0
#define TOTAL_C_FILES 0
#define TOTAL_H_FILES 0
#define TOTAL_COMMENTS 0
#define TOTAL_TODO_ITEMS 0

#define BUILDNUMBER "0"

#endif