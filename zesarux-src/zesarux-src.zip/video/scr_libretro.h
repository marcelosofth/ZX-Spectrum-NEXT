/*
 * scr_libretro.h - interface do driver de video do core libretro.
 *
 * Fica em video/ junto dos outros drivers, como os demais scrlibretro_*.h.
 */
#ifndef SCR_LIBRETRO_H
#define SCR_LIBRETRO_H

#include <stdint.h>
#include <stddef.h>

/* Instala os ponteiros de driver do ZEsarUX (scr_putpixel e companhia).
 * Retorna 0 em caso de sucesso, diferente de zero se faltou memoria. */
int scr_libretro_init(void);

/* Libera o framebuffer e desinstala o driver. */
void scr_libretro_end(void);

/* Ponteiro para o framebuffer XRGB8888 mais recente, com largura, altura e
 * pitch em bytes. Devolve NULL antes de scr_libretro_init(). */
const uint32_t *zx_libretro_framebuffer(unsigned *width, unsigned *height,
                                         size_t *pitch_bytes);

/* Teclado virtual (F8 do ZEsarUX). Chamadas pelo libretro.c. */
void zx_libretro_osk_toggle(void);
void zx_libretro_osk_close(void);
int  zx_libretro_osk_active(void);
void zx_libretro_osk_move(int dir);   /* 0 cima, 1 baixo, 2 esquerda, 3 direita */
void zx_libretro_osk_select(void);
void zx_libretro_osk_tick(void);      /* 1x por quadro, antes de zx_run_frame */

#endif

#ifdef ZX_TRACE_CAIXA
/* Medicao do retangulo realmente escrito no framebuffer. Usado para
 * diagnosticar a posicao da tela sem chutar correcao. */
void zx_caixa_reset(void);
void zx_caixa_dump(void);

/* Quantos pixels foram escritos desde o ultimo reset. A medicao de tempo usa
 * isto para comparar quadro lento com quadro de redesenho completo. */
unsigned zx_caixa_pixels(void);
#endif