﻿/*
 * scr_libretro.c - driver de video do core libretro do ZEsarUX
 *
 * Derivado de video/scrtemplate.c, que e o modelo que o proprio ZEsarUX traz
 * para servir de exemplo a quem quiser escrever um driver novo.
 *
 * A interface e a mesma de qualquer driver grafico: o emulador chama
 * scr_putpixel(x,y,indice_de_cor) para cada pixel da maquina, e o driver
 * decide o que fazer com ele. Nosotros interceptamos na variante _rgb, que ja
 * recebe a cor convertido para RGB -- assim nao precisamos da tabela de
 * indices do Spectrum.
 *
 * Diferenca importante em relacao ao ZEsarUX original: aqui nao desenhamos
 * nenhuma janela e nao temos overlay de menu. O RetroArch cuida de tudo
 * nisso. Por isso NAO chamamos screen_render_menu_overlay_if_active() nem
 * draw_middle_footer(), que scrtemplate chama e que so fariam sentido se
 * fossemos desenhar a interface do ZXVision dentro do nosso framebuffer.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "compileoptions.h"
#include "cpu.h"
#include "screen.h"
#include "charset.h"
#include "debug.h"
#include "zxvision.h"
#include "cpc.h"
#include "pcw.h"
#include "settings.h"
#include "utils.h"      /* util_set_reset_key, UTIL_KEY_* (teclado virtual) */

#include "scr_libretro.h"

/* O Next tem tela maxima de 1280x960. O retro_get_system_av_info do core
 * anuncia exatamente este tamanho e os modos menores sao centralizados
 * dentro dele, porque o libretro so aceita um av_info fixo e a resolucao do
 * Next muda em execucao (vem do registro tbblue_registers[112]). */
#define ZX_FB_WIDTH   1408
#define ZX_FB_HEIGHT  1216

/* Zoom: tres recortes 4:3 centralizados no jogo, todos com borda.
 * O botao Select (ver libretro.c) chama zx_libretro_zoom_next(). */
static const struct { int x, y, w, h; } zx_zoom_tab[3] = {
    {   0,  80, 1408, 1056 },   /* 1x */
    {  96, 152, 1216,  912 },   /* 2x */
    { 160, 200, 1088,  816 },   /* 3x */
};
static int zx_zoom_nivel = 0;

void zx_libretro_zoom_next(void)
{
    zx_zoom_nivel = (zx_zoom_nivel + 1) % 3;
}

static uint32_t *zx_framebuffer;
static uint32_t *zx_osk_buf;       /* copia do recorte + teclado virtual */
static int zx_fb_width  = ZX_FB_WIDTH;
static int zx_fb_height = ZX_FB_HEIGHT;
static int zx_needs_upload;

/* ------------------------------------------------------------- medicao ---
 *
 * Para diagnosticar a posicao da tela, e para medir onde o tempo de um
 * retro_run vai. Tudo sob ZX_TRACE_CAIXA, desligado na build de producao.
 *
 * A caixa e' o retangulo realmente escrito pelos pixels, e nao o que o
 * emulador DEVERIA escrever: e o que de fato saiu de scr_putpixel. A
 * diferenca entre os dois e' justamente o que faz a tela aparecer
 * deslocada. */
#ifdef ZX_TRACE_CAIXA
static int zx_box_x0, zx_box_y0, zx_box_x1, zx_box_y1;
static long zx_box_pixels;
static long zx_box_cortados;

void zx_caixa_reset(void)
{
    zx_box_x0 = zx_box_y0 = 0x7FFFFFFF;
    zx_box_x1 = zx_box_y1 = -1;
    zx_box_pixels = 0;
    zx_box_cortados = 0;
}

unsigned zx_caixa_pixels(void)
{
    return (unsigned)zx_box_pixels;
}

void zx_caixa_dump(void)
{
    if (zx_box_x1 < 0)
    {
        fprintf(stderr, "[caixa] nenhum pixel escrito\n");
        return;
    }
    fprintf(stderr, "[caixa] x %d..%d  y %d..%d  = %dx%d  pixels=%ld  (buffer %dx%d)\n",
            zx_box_x0, zx_box_x1, zx_box_y0, zx_box_y1,
            zx_box_x1 - zx_box_x0 + 1, zx_box_y1 - zx_box_y0 + 1,
            zx_box_pixels, zx_fb_width, zx_fb_height);
    fprintf(stderr, "[caixa] pixels fora do buffer (cortados): %ld\n", zx_box_cortados);
}
#endif

/* --------------------------------------------------------------- video --- */

#ifdef ZX_DEBUG_PIXEL
extern unsigned long zx_debug_pixels_total;
unsigned long zx_debug_pixels_total = 0;
#endif

/* ------------------------------------------------------------------ custo --
 *
 * Medir o custo de video DIRETO, e nao por correlacao com o numero de
 * pixels. Correlacao engana: dois quadros com os mesmos pixels podem ter
 * tempos bem diferentes, porque o tempo depende de trabalho que o contador
 * de pixels nao ve (composicao das camadas por scanline, sprites, DMA,
 * copper) e do agendador do Windows.
 *
 * Aexperimento que resolve: rodar os MESMOS quadros duas vezes, uma com o
 * putpixel ativo e outra com ele desligado. A diferenca e' o custo do
 * desenho, sem nenhuma inferencia. As duas medidas precisam ser da MESMA
 * execucao do mesmo jogo -- por isso o contador e' separado e o desligamento
 * e' por env, e nao por flag em tempo de execucao.
 *
 * Com ZX_PUTPIXEL_OFF=1 o putpixel conta e sai, sem escrever no framebuffer.
 */
#ifdef ZX_TRACE_CUSTO
static int zx_putpixel_off = 0;
unsigned long long zx_custo_chamadas = 0;     /* chamadas ao putpixel */
unsigned long long zx_custo_fim_us = 0;       /* tempo total do refresh */
unsigned long long zx_custo_ref0 = 0;         /* inicio do quadro (ver o glue) */
unsigned long long zx_custo_pg0 = 0;           /* page faults no inicio do quadro */
unsigned long long zx_custo_falhas_pg = 0;    /* page faults por quadro */

/* Page faults: a hipotese mais barata para a parcela de tempo em que a
 * thread esta fora da CPU. Se o emulador aloca e uma pagina nova por quadro,
 * o Windows precisa traz-la do disco e a thread BLOCKIA -- e isso aparece
 * como tempo de CPU menor que o tempo de parede, sem custo de codigo.
 *
 * psapi.h e' obrigatorio: windows.h sozinho nao declara
 * PROCESS_MEMORY_COUNTERS_EX nem GetProcessMemoryInfo. No Linux isto
 * desaparece: nao existe essa medicao. */
#ifdef ZX_TRACE_CUSTO
#include <psapi.h>
#endif

/* NAO e' static: o glue chama esta funcao (extern) para medir o delta de
 * page faults a cada quadro. */
unsigned long long zx_falhas_pg_agora(void)
{
    PROCESS_MEMORY_COUNTERS_EX mc;
    memset(&mc, 0, sizeof(mc));
    mc.cb = sizeof(mc);
    if (GetProcessMemoryInfo(GetCurrentProcess(),
            (PROCESS_MEMORY_COUNTERS *)&mc, sizeof(mc)))
        return (unsigned long long)mc.PageFaultCount;
    return 0;
}

static long long zx_custo_agora_us(void)
{
    LARGE_INTEGER c, f;
    static LARGE_INTEGER freq = {0};
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&c);
    return (c.QuadPart * 1000000LL) / freq.QuadPart;
}
#endif

static void scrlibretro_putpixel_final_rgb(int x, int y, unsigned int color_rgb)
{
#ifdef ZX_DEBUG_PIXEL
    zx_debug_pixels_total++;
#endif

#ifdef ZX_TRACE_CUSTO
    /* NAO cronometro cada pixel. A primeira versao media, e o proprio
     * relogio (2 chamadas de QueryPerformanceCounter por pixel, ~52 mil
     * pixels por quadro) inflou o quadro em ~2,9 ms -- mais que o tempo que
     * eu queria medir. O custo do putpixel vem do experimento A/B
     * (ZX_PUTPIXEL_OFF), que e' exato e nao custa nada. */
    zx_custo_chamadas++;
#endif
#ifdef ZX_TRACE_CAIXA
    /* Medido ANTES do recorte de proposito. Se o Next escreve com offset
     * grande, o pixels cai fora do buffer e a caixa mediria menos do que o
     * emulador tentou desenhar -- que e' justamente o que queremos ver. */
    if (x < zx_box_x0) zx_box_x0 = x;
    if (y < zx_box_y0) zx_box_y0 = y;
    if (x > zx_box_x1) zx_box_x1 = x;
    if (y > zx_box_y1) zx_box_y1 = y;
    zx_box_pixels++;
    if (x < 0 || y < 0 || x >= zx_fb_width || y >= zx_fb_height)
        zx_box_cortados++;
#endif

    if (x < 0 || y < 0 || x >= zx_fb_width || y >= zx_fb_height)
        return;

    /* O flag e' do experimento A/B (ZX_PUTPIXEL_OFF), que so existe no build de
 * medicao. No build normal o putpixel escreve sempre -- e assim que ele
 * precisa ficar, senao o framebuffer nunca enche. */
#if defined(ZX_TRACE_CUSTO)
    if (!zx_putpixel_off)
#endif
#if defined(ZX_PUTPIXEL_NULO)
    /* Build de REFERENCIA do experimento A/B: o putpixel conta e sai, sem
     * escrever no framebuffer. Compilado sem nenhum tracing, para que a
     * comparacao com o build normal seja justa: os dois com o mesmo custo de
     * tudo, diferindo SO na escrita do pixel.
     *
     * Este if nao entra no build de producao -- e' so para a medicao. */
    (void)0;
#else
        zx_framebuffer[(size_t)y * zx_fb_width + x] = (uint32_t)(color_rgb & 0x00FFFFFFu);
#endif
    zx_needs_upload = 1;
}

static void scrlibretro_putpixel_final(int x, int y, unsigned int color)
{
    /* ESTE e' o caminho que o Spectrum e o Next realmente usam.
     *
     * O emulador desenha por scr_putpixel(x,y,color) com color sendo um
     * INDICE da paleta do Spectrum (0..15), nao uma cor RGB:
     *
     *     screen.c:1702   scr_putpixel(x,y,color);
     *
     * A variante _rgb (scrlibretro_putpixel_final_rgb) so e' chamada pelo
     * caminho de indice, em screen.c:2977, e nao pelo desenho normal do
     * Spectrum. Discardar este pixel -- como a primeira versao fazia -- deixa
     * o framebuffer em preto e trava o laco de emulacao.
     *
     * A conversao e spectrum_colortable[color], exatamente como o proprio
     * scrtemplate.c sugere no comentario e como scrcaca.c e scraa.c fazem.
     *
     * O layout ja e' o que o libretro quer: o ZEsarUX guarda 0x00RRGGBB
     * (screen.c:1986-1988 extrai R do bit 16) e o XRGB8888 do RetroArch e'
     * 0x00RRGGBB tambem. Nao ha conversao de canais, so mascarar o byte
     * alto, que ja e' zero. */
    unsigned int rgb = spectrum_colortable[color];

    scrlibretro_putpixel_final_rgb(x, y, rgb);
}

/* Cada pixel da maquina passa por aqui antes de ir para o driver. E aqui que
 * o overlay do ZXVision seria misturado; como nao queremos overlay, so
 * repassamos o pixel quando o menu esta fechado, exatamente como faz o
 * scrtemplate. */
static void scrlibretro_putpixel(int x, int y, unsigned int color)
{
    if (menu_overlay_activo == 0)
    {
        scr_putpixel_final(x, y, color);
        return;
    }

    /* Com o overlay ativo (nao deve acontecer num core libretro, mas o
     * emulador pode pedir) descartamos o pixel em vez de tentar misturar
     * camadas que aqui nao existem. */
    (void)x; (void)y; (void)color;
}

/* ----------------------------------------------------------------- resto --- */

static void scrlibretro_putchar_zx8081(int x, int y, z80_byte caracter)
{
    scr_putchar_zx8081_comun(x, y, caracter);
}

static void scrlibretro_debug_registers(void)
{
    char buffer[2048];
    print_registers(buffer);
    printf("%s\r", buffer);
}

static void scrlibretro_messages_debug(char *s)
{
    printf("%s\n", s);
    fflush(stdout);
}

static void scrlibretro_putchar_menu(int x, int y, z80_byte caracter, int tinta, int papel)
{
    (void)x; (void)y; (void)caracter; (void)tinta; (void)papel;
}

static void scrlibretro_putchar_footer(int x, int y, z80_byte caracter, int tinta, int papel)
{
    (void)x; (void)y; (void)caracter; (void)tinta; (void)papel;
}

/* Valores minimos plausiveis caso o emulador os consulte. O ZXVision esta
 * desligado, entao nunca sao usados de verdade. */
static int scrlibretro_get_menu_width(void)
{
    return 32;
}

static int scrlibretro_get_menu_height(void)
{
    return 24;
}

static void scrlibretro_set_fullscreen(void)   { }
static void scrlibretro_reset_fullscreen(void) { }
static void scrlibretro_detectedchar_print(z80_byte caracter) { (void)caracter; }
static void scrlibretro_actualiza_tablas_teclado(void) { }
static void scrlibretro_z88_cpc_load_keymap(void)
{
    debug_printf(VERBOSE_INFO, "Loading keymap");
}

static void scrlibretro_refresca_border(void)
{
    scr_refresca_border();
}

static void scrlibretro_refresca_pantalla_zx81(void)
{
    scr_refresca_pantalla_y_border_zx8081();
}

static void scrlibretro_refresca_pantalla(void)
{
    if (sem_screen_refresh_reallocate_layers)
        return;

#ifdef ZX_TRACE_CUSTO
    long long custo_t0 = zx_custo_agora_us();
#endif

    sem_screen_refresh_reallocate_layers = 1;

    /* scrtemplate tambem chama screen_render_menu_overlay_if_active() e
     * draw_middle_footer() aqui. Nao copiamos: sao o menu do ZXVision, que o
     * RetroArch substitui pelo seu proprio. */

    if (MACHINE_IS_ZX8081)
        scrlibretro_refresca_pantalla_zx81();
    else if (MACHINE_IS_SPECTRUM)
    {
        /* O Next (TBBLUE) tambem satisfaz MACHINE_IS_SPECTRUM, e e por
         * esse caminho que ele desenha. */
        if (rainbow_enabled.v == 0)
        {
            if (border_enabled.v && modificado_border.v)
            {
                scrlibretro_refresca_border();
                modificado_border.v = 0;
            }
            scr_refresca_pantalla_comun();
        }
        else
        {
            scr_refresca_pantalla_rainbow_comun_spectrum();
        }
    }
    else if (MACHINE_IS_Z88)
    {
        screen_z88_refresca_pantalla();
    }
    else if (MACHINE_IS_ACE)
    {
        scr_refresca_pantalla_y_border_ace();
    }
    else if (MACHINE_IS_CPC)
    {
        scr_refresca_pantalla_y_border_cpc();
    }
    else if (MACHINE_IS_PCW)
    {
        scr_refresca_pantalla_y_border_pcw();
    }

    sem_screen_refresh_reallocate_layers = 0;

#ifdef ZX_TRACE_CUSTO
    /* Tempo do refresh inteiro (todo o desenho, nao so o putpixel). A
     * diferenca entre isto e o total do quadro, menos os passos de CPU, e'
     * o trabalho de video que o emulador faz. */
    zx_custo_fim_us += (unsigned long long)(zx_custo_agora_us() - custo_t0);
#endif
}

static void scrlibretro_end(void)
{
    debug_printf(VERBOSE_INFO, "Closing libretro video driver");
}

static z80_byte scrlibretro_lee_puerto(z80_byte puerto_h, z80_byte puerto_l)
{
    (void)puerto_h; (void)puerto_l;
    return 255;
}

/* --------------------------------------------------------------- init --- */

int scr_libretro_init(void)
{
    debug_printf(VERBOSE_INFO, "Init libretro Video Driver");

#ifdef ZX_TRACE_CUSTO
    /* Desligar o putpixel pela env ZX_PUTPIXEL_OFF=1. E' o experimento de
     * referencia: a MESMA execucao do MESMO jogo, so que sem escrever pixel
     * no framebuffer. A diferenca de tempo entre as duas e' o custo do
     * desenho -- medido, nao inferido. */
    {
        const char *v = getenv("ZX_PUTPIXEL_OFF");
        zx_putpixel_off = (v && v[0] == '1') ? 1 : 0;
        fprintf(stderr, "[custo] putpixel %s\n",
                zx_putpixel_off ? "DESLIGADO (medida de referencia)" : "ligado");
    }
#endif

    if (!zx_framebuffer)
    {
        zx_framebuffer = (uint32_t *)malloc((size_t)ZX_FB_WIDTH * ZX_FB_HEIGHT * sizeof(uint32_t));
        if (!zx_framebuffer)
            return 1;
        memset(zx_framebuffer, 0, (size_t)ZX_FB_WIDTH * ZX_FB_HEIGHT * sizeof(uint32_t));
    }

    zx_needs_upload = 1;

    /* O driver se registra em DOIS lugares, e no mesmo padrao de todos os
     * drivers do ZEsarUX (veja o bloco do driver null, start.c:2466-2468):
     *
     *     scr_init_pantalla      = scrnull_init;
     *     scr_refresca_pantalla  = scrnull_refresca_pantalla;
     *
     * O primeiro e' o INICIALIZADOR, chamado uma vez. O segundo e' a funcao de
     * DESENHO, e e' o que screen.c:10237 chama a cada quadro:
     *
     *     if (screen_if_refresh()) {
     *         scr_refresca_pantalla();      <- este ponteiro
     *
     * Sem o segundo, o emulador chega ao fim do quadro e salta para o endereco
     * 0x0. O scrtemplate.c nao aparece registrando este porque ele e' so um
     * modelo de inicializacao: a atribuicao do refresh fica a cargo de quem
     * instala o driver, em start.c. Nos somos o instalador. */
    scr_refresca_pantalla      = scrlibretro_refresca_pantalla;

    scr_putpixel              = scrlibretro_putpixel;
    scr_putpixel_final        = scrlibretro_putpixel_final;
    scr_putpixel_final_rgb    = scrlibretro_putpixel_final_rgb;

    /* Largura/altura do menu sao irrelevantes aqui: o ZXVision esta desligado
     * num core libretro. Mas os ponteiros precisam existir, porque o emulador
     * os consulta em varios lugares sem checar se o driver os preencheu. */
    scr_get_menu_width        = scrlibretro_get_menu_width;
    scr_get_menu_height       = scrlibretro_get_menu_height;

    scr_putchar_zx8081        = scrlibretro_putchar_zx8081;
    scr_debug_registers       = scrlibretro_debug_registers;
    scr_messages_debug        = scrlibretro_messages_debug;
    scr_putchar_menu          = scrlibretro_putchar_menu;
    scr_putchar_footer        = scrlibretro_putchar_footer;

    /* Este NAO pode faltar. O core chama, a cada 1/50 s:
     *     core_spectrum.c:1161   scr_actualiza_tablas_teclado();
     * logo antes do realjoystick_main(). Como e' um ponteiro global e o
     * emulador chama sem checar, deixar em NULL e um salto para o endereco
     * 0x0 -- o que foi o SIGSEGV em cpu_core_loop_spectrum+224.
     *
     * Aqui nao ha tecla fisica para ler: o teclado chega por input_state_cb
     * e e injetado em zx_set_key. Esta funcao so atualiza a "tabla de teclas"
     * que o emulador usa para detectar Shift/Caps, entao fica vazia de novo,
     * mas tem de EXISTIR. */
    scr_actualiza_tablas_teclado = scrlibretro_actualiza_tablas_teclado;

    scr_set_fullscreen        = scrlibretro_set_fullscreen;
    scr_reset_fullscreen      = scrlibretro_reset_fullscreen;
    scr_z88_cpc_load_keymap   = scrlibretro_z88_cpc_load_keymap;
    scr_detectedchar_print    = scrlibretro_detectedchar_print;
    scr_update_window_title   = NULL;
    scr_get_text_clipboard    = NULL;
    scr_tiene_colores         = 1;
    screen_refresh_menu       = 1;

    /* O nome precisa ser unico: o ZEsarUX usa a string para disqualificar
     * drivers no menu de opcoes. "libretro" e melhor que "null" porque o
     * driver null e o que faz o emulador nao escrever nada. */
    scr_set_driver_name("libretro");

    return 0;
}

void scr_libretro_end(void)
{
    scrlibretro_end();
    if (zx_osk_buf)
    {
        free(zx_osk_buf);
        zx_osk_buf = NULL;
    }
    if (zx_framebuffer)
    {
        free(zx_framebuffer);
        zx_framebuffer = NULL;
    }
}

/* ====================================================================== */
/* Teclado virtual: o equivalente do F8 ("On Screen Keyboard") do ZEsarUX.  */
/*                                                                        */
/* Por que nao usamos o do ZXVision: aqui o ZXVision esta desligado e o   */
/* menu do ZEsarUX roda num laco bloqueante (menu_inicio), que dentro do  */
/* retro_run congelaria o RetroArch. Entao o core desenha o seu proprio,  */
/* com o mesmo layout, e injeta as teclas por util_set_reset_key (o mesmo */
/* caminho do teclado fisico).                                            */
/*                                                                        */
/* O desenho NAO vai para zx_framebuffer: o emulador nao repinta o quadro */
/* inteiro a cada frame, entao qualquer coisa escrita la ficaria "grudada" */
/* na tela depois de fechar. O teclado e' composto numa COPIA do recorte, */
/* so quando esta aberto (ver zx_libretro_framebuffer).                   */
/* ====================================================================== */

#define OSK_S            4                 /* tamanho de um pixel de fonte  */
#define OSK_COLS         27                /* mesma janela do ZEsarUX       */
#define OSK_ROWS         12
#define OSK_FW           (OSK_COLS * 8)    /* largura em pixels de fonte    */
#define OSK_FH           (OSK_ROWS * 8)
#define OSK_HOLD_FRAMES  10                /* tecla segurada ~0,2 s a 50 Hz */

#define OSK_COR_PRETO    0x000000u
#define OSK_COR_AZUL     0x0055AAu
#define OSK_COR_CLARO    0xE0E0E0u
#define OSK_COR_CIANO    0x00FFFFu

typedef struct { const char *txt; int x; int w; } zx_osk_key_t;

/* Mesma tabela do ZEsarUX (menu_items.c, teclas_osd[]): 4 linhas de 10. */
static const zx_osk_key_t zx_osk_keys[40] = {
    {"1",0,1},{"2",2,1},{"3",4,1},{"4",6,1},{"5",8,1},{"6",10,1},{"7",12,1},{"8",14,1},{"9",16,1},{"0",18,1},
    {"Q",1,1},{"W",3,1},{"E",5,1},{"R",7,1},{"T",9,1},{"Y",11,1},{"U",13,1},{"I",15,1},{"O",17,1},{"P",19,1},
    {"A",1,1},{"S",3,1},{"D",5,1},{"F",7,1},{"G",9,1},{"H",11,1},{"J",13,1},{"K",15,1},{"L",17,1},{"ENT",19,3},
    {"CS",0,2},{"Z",3,1},{"X",5,1},{"C",7,1},{"V",9,1},{"B",11,1},{"N",13,1},{"M",15,1},{"SS",17,2},{"SP",20,2}
};

static int           zx_osk_aberto;
static int           zx_osk_cx, zx_osk_cy;     /* cursor: x 0..9, y 0..4 */
static int           zx_osk_sticky;
static unsigned char zx_osk_marcada[40];       /* marcadas (modo Stick)  */
static unsigned char zx_osk_segura[40];        /* sendo seguradas agora  */
static int           zx_osk_quadros;           /* quadros ate soltar     */

/* contexto de desenho */
static uint32_t *osk_d;
static int       osk_bw, osk_bh, osk_ox, osk_oy;

static int osk_indice(void)
{
    return zx_osk_cy * 10 + zx_osk_cx;     /* 40 = Stick, 41 = Send */
}

/* ------------------------------------------------------------- teclas --- */

static void osk_tecla(int i, int down)
{
    const char *t = zx_osk_keys[i].txt;
    int k;

    if (t[1] == 0)
        k = (t[0] >= 'A' && t[0] <= 'Z') ? (t[0] - 'A' + 'a') : t[0];
    else if (!strcmp(t, "ENT")) k = UTIL_KEY_ENTER;
    else if (!strcmp(t, "SP"))  k = UTIL_KEY_SPACE;
    else if (!strcmp(t, "CS"))  k = UTIL_KEY_SHIFT_L;
    else if (!strcmp(t, "SS"))  k = UTIL_KEY_ALT_L;   /* Symbol Shift */
    else return;

    util_set_reset_key((enum util_teclas)k, down ? 1 : 0);
}

static void osk_soltar_tudo(void)
{
    int i;
    for (i = 0; i < 40; i++)
        if (zx_osk_segura[i])
        {
            osk_tecla(i, 0);
            zx_osk_segura[i] = 0;
        }
}

static void osk_enviar(void)
{
    int i, algum = 0;

    osk_soltar_tudo();
    for (i = 0; i < 40; i++)
        if (zx_osk_marcada[i])
        {
            osk_tecla(i, 1);
            zx_osk_segura[i] = 1;
            algum = 1;
        }
    if (algum)
        zx_osk_quadros = OSK_HOLD_FRAMES;
    if (!zx_osk_sticky)
        memset(zx_osk_marcada, 0, sizeof(zx_osk_marcada));
}

/* Uma vez por quadro, ANTES de zx_run_frame, mesmo com o teclado fechado:
 * a tecla enviada precisa ser solta mesmo que o usuario feche o teclado. */
void zx_libretro_osk_tick(void)
{
    if (zx_osk_quadros > 0 && --zx_osk_quadros == 0)
        osk_soltar_tudo();
}

int zx_libretro_osk_active(void)
{
    return zx_osk_aberto;
}

void zx_libretro_osk_close(void)
{
    zx_osk_aberto = 0;
    /* como o ESC do original: descarta marcas e Stick */
    zx_osk_sticky = 0;
    memset(zx_osk_marcada, 0, sizeof(zx_osk_marcada));
}

void zx_libretro_osk_toggle(void)
{
    if (zx_osk_aberto)
        zx_libretro_osk_close();
    else
        zx_osk_aberto = 1;
}

/* dir: 0 cima, 1 baixo, 2 esquerda, 3 direita (mesma regra do original) */
void zx_libretro_osk_move(int dir)
{
    switch (dir)
    {
        case 0:
            if (zx_osk_cy > 0) zx_osk_cy--;
            break;
        case 1:
            if (zx_osk_cy < 4) zx_osk_cy++;
            if (zx_osk_cy == 4) zx_osk_cx = 0;      /* cai em Stick */
            break;
        case 2:
            if (zx_osk_cx > 0) zx_osk_cx--;
            break;
        case 3:
            if (zx_osk_cy == 4) { if (zx_osk_cx < 1) zx_osk_cx++; }
            else if (zx_osk_cx < 9) zx_osk_cx++;
            break;
    }
}

/* Enter/fogo no cursor. Mesma logica de menu_onscreen_send_enter_check_exit. */
void zx_libretro_osk_select(void)
{
    int idx = osk_indice();

    if (idx == 40)                       /* Stick */
    {
        zx_osk_sticky ^= 1;
        if (!zx_osk_sticky)
            memset(zx_osk_marcada, 0, sizeof(zx_osk_marcada));
        return;
    }

    if (!zx_osk_sticky)
        memset(zx_osk_marcada, 0, sizeof(zx_osk_marcada));

    if (idx != 41)                       /* 41 = Send: so envia */
        zx_osk_marcada[idx] ^= 1;

    if (zx_osk_sticky && idx != 41)      /* em Stick so envia no Send */
        return;

    osk_enviar();
}

/* ------------------------------------------------------------ desenho --- */

/* Retangulo em PIXELS DE FONTE relativos a janela. */
static void osk_fill(int fx, int fy, int fw, int fh, uint32_t cor)
{
    int x0 = osk_ox + fx * OSK_S, y0 = osk_oy + fy * OSK_S;
    int x1 = x0 + fw * OSK_S,     y1 = y0 + fh * OSK_S;
    int x, y;

    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > osk_bw) x1 = osk_bw;
    if (y1 > osk_bh) y1 = osk_bh;

    for (y = y0; y < y1; y++)
        for (x = x0; x < x1; x++)
            osk_d[(size_t)y * osk_bw + x] = cor;
}

static void osk_char(int fx, int fy, char ch, uint32_t fg, int com_fundo, uint32_t bg)
{
    const unsigned char *cs = char_set ? char_set : char_set_spectrum;
    const unsigned char *g;
    int row, col;

    if (ch < 32 || ch > 126)
        ch = '?';
    g = &cs[(ch - 32) * 8];

    for (row = 0; row < 8; row++)
        for (col = 0; col < 8; col++)
        {
            if (g[row] & (0x80 >> col))
                osk_fill(fx + col, fy + row, 1, 1, fg);
            else if (com_fundo)
                osk_fill(fx + col, fy + row, 1, 1, bg);
        }
}

static void osk_texto(int fx, int fy, const char *s, uint32_t fg, int com_fundo, uint32_t bg)
{
    for (; *s; s++, fx += 8)
        osk_char(fx, fy, *s, fg, com_fundo, bg);
}

/* Uma tecla: normal, marcada/segura (invertida) ou sob o cursor (ciano). */
static void osk_desenha_tecla(const char *txt, int col, int lin, int largura,
                              int marcada, int cursor)
{
    int fx = col * 8, fy = lin * 8;
    uint32_t fg = OSK_COR_CLARO, bg = OSK_COR_AZUL;

    if (cursor)       { fg = OSK_COR_PRETO; bg = OSK_COR_CIANO; }
    else if (marcada) { fg = OSK_COR_AZUL;  bg = OSK_COR_CLARO; }

    osk_fill(fx, fy, largura * 8, 8, bg);
    osk_texto(fx, fy, txt, fg, 0, bg);
}

static void osk_desenha(void)
{
    static const char *icone[6] = {
        ".####.", "#X##X#", "##XX##", "##XX##", "#X##X#", ".####."
    };
    static const uint32_t arco[4] = { 0xFF0000u, 0xFFFF00u, 0x00FF00u, 0x00FFFFu };
    int i, r, c, idx = osk_indice();

    /* moldura preta e corpo azul (1 pixel de fonte de borda) */
    osk_fill(0, 0, OSK_FW, OSK_FH, OSK_COR_PRETO);
    osk_fill(1, 8, OSK_FW - 2, OSK_FH - 8 - 1, OSK_COR_AZUL);

    /* barra de titulo */
    for (r = 0; r < 6; r++)
        for (c = 0; c < 6; c++)
            if (icone[r][c] == '#')
                osk_fill(1 + c, 1 + r, 1, 1, OSK_COR_CLARO);
    osk_texto(16, 0, "On Screen Keyboard", OSK_COR_CLARO, 0, OSK_COR_PRETO);

    for (i = 0; i < 8; i++)                       /* faixas do arco-iris */
        osk_fill(169 + i * 4, 0, 2, 8, arco[i / 2]);

    osk_fill(202, 2, 4, 4, OSK_COR_CLARO);        /* minimizar */
    osk_fill(203, 3, 2, 2, OSK_COR_PRETO);
    osk_fill(207, 1, 6, 6, OSK_COR_CLARO);        /* maximizar */
    osk_fill(208, 2, 4, 4, OSK_COR_PRETO);

    for (i = 0; i < 5; i++)                       /* canto de redimensionar */
        osk_fill(OSK_FW - 1 - i, OSK_FH - 5 + i, i + 1, 1, OSK_COR_PRETO);

    /* as 40 teclas: coluna = 1 + x, linha = 2 + 2 * fileira */
    for (i = 0; i < 40; i++)
        osk_desenha_tecla(zx_osk_keys[i].txt, 1 + zx_osk_keys[i].x,
                          2 + (i / 10) * 2, zx_osk_keys[i].w,
                          zx_osk_marcada[i] || zx_osk_segura[i], idx == i);

    osk_desenha_tecla("Stick", 1, 10, 5, zx_osk_sticky, idx == 40);
    osk_desenha_tecla("Send",  7, 10, 4, 0,             idx == 41);
}

/* Copia o recorte visivel e desenha o teclado centralizado por cima. */
static const uint32_t *osk_compose(const uint32_t *src, int w, int h, size_t src_pitch_px)
{
    int y;

    if (!zx_osk_buf)
    {
        zx_osk_buf = (uint32_t *)malloc((size_t)ZX_FB_WIDTH * ZX_FB_HEIGHT * sizeof(uint32_t));
        if (!zx_osk_buf)
            return NULL;
    }
    if (w > ZX_FB_WIDTH || h > ZX_FB_HEIGHT)
        return NULL;

    for (y = 0; y < h; y++)
        memcpy(zx_osk_buf + (size_t)y * w, src + y * src_pitch_px, (size_t)w * sizeof(uint32_t));

    osk_d  = zx_osk_buf;
    osk_bw = w;
    osk_bh = h;
    osk_ox = (w - OSK_FW * OSK_S) / 2;
    osk_oy = (h - OSK_FH * OSK_S) / 2;
    osk_desenha();

    /* Transparencia de 30%: o teclado foi desenhado opaco em zx_osk_buf; aqui
     * cada pixel da janela vira 70% teclado + 30% pixel original do jogo
     * (src). Pesos 179/77 (somam 256); R e B sao calculados juntos e G
     * separado, para nenhum canal "vazar" para o vizinho. */
    {
        int x0 = osk_ox < 0 ? 0 : osk_ox;
        int y0 = osk_oy < 0 ? 0 : osk_oy;
        int x1 = osk_ox + OSK_FW * OSK_S; if (x1 > w) x1 = w;
        int y1 = osk_oy + OSK_FH * OSK_S; if (y1 > h) y1 = h;
        int x;

        for (y = y0; y < y1; y++)
            for (x = x0; x < x1; x++)
            {
                uint32_t a = src[(size_t)y * src_pitch_px + x];
                uint32_t b = zx_osk_buf[(size_t)y * w + x];
                uint32_t rb = (((b & 0xFF00FFu) * 179u + (a & 0xFF00FFu) * 77u) >> 8) & 0xFF00FFu;
                uint32_t g  = (((b & 0x00FF00u) * 179u + (a & 0x00FF00u) * 77u) >> 8) & 0x00FF00u;
                zx_osk_buf[(size_t)y * w + x] = rb | g;
            }
    }

    return zx_osk_buf;
}

/* ------------------------------------------------- leitura pelo core --- */

const uint32_t *zx_libretro_framebuffer(unsigned *width, unsigned *height, size_t *pitch_bytes)
{
    if (!zx_framebuffer)
        return NULL;

    if (zx_needs_upload)
        zx_needs_upload = 0;

    /* Entregamos o framebuffer INTEIRO.
     *
     * Medido (ZX_TRACE_CAIXA): o emulador escreve de x=0 a 1279 e de y=0 a
     * 959, ou seja, o desktop inteiro do Next, sem offset. Se entregassemos
     * aqui um recorte menor -- a janela do Spectrum, 704x608 -- o frontend
     * mostraria so o canto de cima a esquerda.
     *
     * O pitch e' o do buffer real, 1280 pixels. Aqui width, height e pitch
     * coincidem porque a imagem ocupa tudo; se um dia o emulador passar a
     * centralizar num desktop maior, o pitch e' que diria onde comeca a
     * proxima linha. */
    /* Recorte: o pitch continua o do buffer inteiro; so o ponteiro inicial
     * e o tamanho mudam. */
    *width = (unsigned)zx_zoom_tab[zx_zoom_nivel].w;
    *height = (unsigned)zx_zoom_tab[zx_zoom_nivel].h;
    *pitch_bytes = (size_t)zx_fb_width * sizeof(uint32_t);

    {
        const uint32_t *recorte = zx_framebuffer
                          + (size_t)zx_zoom_tab[zx_zoom_nivel].y * zx_fb_width
                          + zx_zoom_tab[zx_zoom_nivel].x;

        /* Teclado virtual aberto: entrega uma COPIA do recorte com o teclado
         * desenhado por cima. O zx_framebuffer em si nunca e' tocado. */
        if (zx_osk_aberto)
        {
            const uint32_t *com_osk = osk_compose(recorte, (int)*width, (int)*height,
                                                  (size_t)zx_fb_width);
            if (com_osk)
            {
                *pitch_bytes = (size_t)*width * sizeof(uint32_t);
                return com_osk;
            }
        }
        return recorte;
    }
}